
import React from 'react';
import { CactusIcon } from './Icons';

interface ObstacleProps {
  x: number;
  width: number;
  height: number;
}

export const Obstacle: React.FC<ObstacleProps> = ({ x, width, height }) => {
  return (
    <div
      className="absolute"
      style={{
        left: `${x}px`,
        bottom: '20px',
        width: `${width}px`,
        height: `${height}px`,
      }}
    >
      <CactusIcon />
    </div>
  );
};
