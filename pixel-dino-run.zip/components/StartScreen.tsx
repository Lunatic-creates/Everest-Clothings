
import React from 'react';

export const StartScreen: React.FC = () => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 bg-opacity-75 z-20">
      <div className="text-center text-gray-700">
        <h1 className="text-3xl font-bold mb-4">Pixel Dino Run</h1>
        <p className="text-lg">Tap screen or press Space to Start</p>
      </div>
    </div>
  );
};
