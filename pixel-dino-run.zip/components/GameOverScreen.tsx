
import React from 'react';

interface GameOverScreenProps {
  score: number;
  onRestart: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({ score, onRestart }) => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 bg-opacity-75 z-20">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-800 mb-2">GAME OVER</h2>
        <p className="text-xl text-gray-600 mb-6">Score: {score}</p>
        <button
          onClick={onRestart}
          className="p-4 rounded-lg bg-gray-700 text-white text-2xl hover:bg-gray-800 focus:outline-none focus:ring-4 focus:ring-gray-500 transition-transform transform active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5M4 4l16 16" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 4v5h-5M4 20v-5h5M20 4L4 20" />
          </svg>
        </button>
      </div>
    </div>
  );
};
