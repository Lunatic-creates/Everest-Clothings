
import React from 'react';
import { DinoIcon } from './Icons';

interface DinoProps {
  y: number;
}

export const Dino: React.FC<DinoProps> = ({ y }) => {
  return (
    <div
      className="absolute"
      style={{
        left: '50px',
        bottom: `${y}px`,
        width: '44px',
        height: '47px',
        transform: 'translateY(0)',
      }}
    >
      <DinoIcon />
    </div>
  );
};
