
export enum GameState {
  Start,
  Playing,
  GameOver,
}

export interface ObstacleState {
  id: number;
  x: number;
  width: number;
  height: number;
}
