
// Game Area Dimensions
export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 250;
export const GROUND_HEIGHT = 20;

// Dino Physics
export const DINO_INITIAL_Y = GROUND_HEIGHT;
export const GRAVITY = 1800; // pixels per second squared
export const JUMP_FORCE = 700; // pixels per second
export const DINO_HITBOX = { width: 44, height: 47 };

// Game Dynamics
export const INITIAL_GAME_SPEED = 250; // pixels per second
export const SPEED_INCREASE = 5; // speed increase per second

// Obstacle Properties
export const OBSTACLE_MIN_SPAWN_TIME = 0.8; // in seconds
export const OBSTACLE_MAX_SPAWN_TIME = 2.0; // in seconds
