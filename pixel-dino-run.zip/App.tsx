
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Dino } from './components/Dino';
import { Obstacle } from './components/Obstacle';
import { GameOverScreen } from './components/GameOverScreen';
import { GameState, ObstacleState } from './types';
import { 
  GAME_WIDTH, 
  GAME_HEIGHT, 
  GROUND_HEIGHT, 
  DINO_INITIAL_Y, 
  GRAVITY, 
  JUMP_FORCE, 
  INITIAL_GAME_SPEED, 
  SPEED_INCREASE, 
  OBSTACLE_MIN_SPAWN_TIME,
  OBSTACLE_MAX_SPAWN_TIME,
  DINO_HITBOX
} from './constants';
import { StartScreen } from './components/StartScreen';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.Start);
  const [dinoY, setDinoY] = useState<number>(DINO_INITIAL_Y);
  const [dinoVelocityY, setDinoVelocityY] = useState<number>(0);
  const [obstacles, setObstacles] = useState<ObstacleState[]>([]);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('dinoHighScore') || '0', 10);
  });
  const [gameSpeed, setGameSpeed] = useState<number>(INITIAL_GAME_SPEED);
  
  const lastTimeRef = useRef<number | null>(null);
  const gameLoopRef = useRef<number>(0);
  const timeToNextObstacleRef = useRef<number>(0);
  const scoreRef = useRef<number>(0);

  const resetGame = useCallback(() => {
    setDinoY(DINO_INITIAL_Y);
    setDinoVelocityY(0);
    setObstacles([]);
    setScore(0);
    scoreRef.current = 0;
    setGameSpeed(INITIAL_GAME_SPEED);
    timeToNextObstacleRef.current = OBSTACLE_MIN_SPAWN_TIME;
    setGameState(GameState.Playing);
  }, []);
  
  const handleJump = useCallback(() => {
    if (gameState === GameState.Playing && dinoY === DINO_INITIAL_Y) {
      setDinoVelocityY(JUMP_FORCE);
    } else if (gameState === GameState.Start) {
      resetGame();
    } else if (gameState === GameState.GameOver) {
       resetGame();
    }
  }, [gameState, dinoY, resetGame]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        handleJump();
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleJump]);
  
  const gameLoop = useCallback((time: number) => {
    if (gameState !== GameState.Playing) return;

    if (lastTimeRef.current === null) {
      lastTimeRef.current = time;
      gameLoopRef.current = requestAnimationFrame(gameLoop);
      return;
    }
    
    const deltaTime = (time - lastTimeRef.current) / 1000; // in seconds
    lastTimeRef.current = time;

    // Update Score & Speed
    scoreRef.current += deltaTime * gameSpeed * 5;
    setScore(Math.floor(scoreRef.current));
    setGameSpeed(prev => prev + SPEED_INCREASE * deltaTime);

    // Update Dino position
    setDinoY(prevY => {
      const newVelocity = dinoVelocityY - GRAVITY * deltaTime;
      setDinoVelocityY(newVelocity);
      let newY = prevY + newVelocity;
      if (newY < DINO_INITIAL_Y) {
        newY = DINO_INITIAL_Y;
        setDinoVelocityY(0);
      }
      return newY;
    });

    // Update Obstacles
    setObstacles(prev => {
      let collisionDetected = false;
      const updatedObstacles = prev.map(obs => {
        const newX = obs.x - gameSpeed * deltaTime;
        // Collision check
        const dinoLeft = 50;
        const dinoRight = dinoLeft + DINO_HITBOX.width;
        const dinoBottom = dinoY;
        const dinoTop = dinoBottom + DINO_HITBOX.height;

        const obsLeft = newX;
        const obsRight = newX + obs.width;
        const obsBottom = GROUND_HEIGHT;
        const obsTop = obsBottom + obs.height;

        if (dinoRight > obsLeft && dinoLeft < obsRight && dinoTop > obsBottom && dinoBottom < obsTop) {
          collisionDetected = true;
        }

        return { ...obs, x: newX };
      }).filter(obs => obs.x > -obs.width);

      if (collisionDetected) {
        setGameState(GameState.GameOver);
        if (score > highScore) {
          setHighScore(score);
          localStorage.setItem('dinoHighScore', score.toString());
        }
      }
      return updatedObstacles;
    });

    // Spawn new obstacles
    timeToNextObstacleRef.current -= deltaTime;
    if (timeToNextObstacleRef.current <= 0) {
      const isTall = Math.random() > 0.5;
      const newObstacle: ObstacleState = {
        id: Date.now(),
        x: GAME_WIDTH,
        width: isTall ? 30 : 25,
        height: isTall ? 60 : 50,
      };
      setObstacles(prev => [...prev, newObstacle]);
      timeToNextObstacleRef.current = OBSTACLE_MIN_SPAWN_TIME + Math.random() * (OBSTACLE_MAX_SPAWN_TIME - OBSTACLE_MIN_SPAWN_TIME);
    }
    
    gameLoopRef.current = requestAnimationFrame(gameLoop);
  }, [gameState, dinoVelocityY, score, highScore, gameSpeed]);
  
  useEffect(() => {
    if (gameState === GameState.Playing) {
      lastTimeRef.current = null;
      scoreRef.current = 0;
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    }
    return () => {
      cancelAnimationFrame(gameLoopRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameState, gameLoop]);

  return (
    <div 
      className="w-screen h-screen bg-gray-100 flex items-center justify-center font-mono select-none"
      onTouchStart={handleJump}
    >
      <div 
        className="relative bg-white overflow-hidden"
        style={{ width: `${GAME_WIDTH}px`, height: `${GAME_HEIGHT}px`, border: '2px solid #333' }}
      >
        <div className="absolute top-4 right-4 text-gray-700 text-xl z-10">
          HI {highScore.toString().padStart(5, '0')} | {score.toString().padStart(5, '0')}
        </div>
        
        {gameState === GameState.Start && <StartScreen />}
        {gameState === GameState.GameOver && <GameOverScreen score={score} onRestart={resetGame} />}

        <div 
          className="absolute bottom-0 left-0 w-full bg-repeat-x"
          style={{ height: `${GROUND_HEIGHT}px`, borderTop: '2px solid #333' }}
        />
        
        <Dino y={dinoY} />

        {obstacles.map(obs => (
          <Obstacle key={obs.id} x={obs.x} width={obs.width} height={obs.height} />
        ))}
      </div>
    </div>
  );
};

export default App;
